require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const db = require('./db/connection');
const moment = require('moment'); // Удобен для дедлайнов

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });
const userStates = {};
const userSessions = {}; // Текущая выбранная группа

console.log('Бот запущен');

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;

  const keyboard = {
    inline_keyboard: [
      [{ text: 'Выбрать группу', callback_data: 'choose_group' }],
      [{ text: 'Добавить группу', callback_data: 'add_group' }],
      [{ text: 'Группы, что ожидают добавление', callback_data: 'pending_groups' }]
    ]
  };

  bot.sendMessage(chatId, 'Привет! Что хочешь сделать?', {
    reply_markup: keyboard
  });

  // Сохраняем пользователя
  db.query('INSERT IGNORE INTO botdb.users (id, chat_id, username) VALUES (?, ?, ?)', [
    msg.from.id,
    chatId,
    msg.from.username || null
  ]);
});

// === CALLBACK ===
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data === 'choose_group') {
    db.query('SELECT * FROM botdb.groups', (err, results) => {
      if (err || results.length === 0) {
        bot.sendMessage(chatId, 'Группы недоступны или произошла ошибка.');
        return;
      }
      const keyboard = {
        inline_keyboard: results.map(g => [{
          text: g.name,
          callback_data: `group_${g.id}`
        }])
      };
      bot.sendMessage(chatId, 'Выберите группу:', { reply_markup: keyboard });
    });
  }

  else if (data.startsWith('group_')) {
    const groupId = parseInt(data.split('_')[1]);
    userSessions[chatId] = { groupId };
    const keyboard = {
      inline_keyboard: [
        [{ text: 'Задачи', callback_data: 'group_tasks' }],
        [{ text: 'Добавить задачу', callback_data: 'add_task' }]
      ]
    };
    bot.sendMessage(chatId, `Вы выбрали группу`, { reply_markup: keyboard });
  }

  else if (data === 'group_tasks') {
    const groupId = userSessions[chatId]?.groupId;
    if (!groupId) return bot.sendMessage(chatId, 'Сначала выберите группу.');

    const sql = `
      SELECT t.id, t.description, t.deadline, t.completed
      FROM botdb.tasks t
      WHERE t.group_id = ? AND t.status = 'подтверждено'
      ORDER BY t.deadline ASC
    `;
    db.query(sql, [groupId], (err, results) => {
      if (err || results.length === 0) {
        bot.sendMessage(chatId, 'Задач нет или произошла ошибка.');
        return;
      }

      results.forEach(task => {
        const text = `📌 *${task.description}*\n⏰ Дедлайн: ${moment(task.deadline).format('DD.MM.YYYY')}\n${task.completed ? '✅ Выполнено' : '❌ Не выполнено'}`;
        const keyboard = {
          inline_keyboard: [[
            { text: task.completed ? '✅ Уже выполнено' : 'Отметить как выполненное', callback_data: `complete_${task.id}` }
          ]]
        };
        bot.sendMessage(chatId, text, { parse_mode: 'Markdown', reply_markup: keyboard });
      });
    });
  }

  else if (data === 'add_group') {
    bot.sendMessage(chatId, 'Введите название новой группы:');
    userStates[chatId] = 'awaiting_group_name';
  }

  else if (data === 'pending_groups') {
    db.query('SELECT * FROM botdb.adding_groups WHERE status = "ожидает"', (err, results) => {
      if (err || results.length === 0) {
        bot.sendMessage(chatId, 'Нет ожидающих групп.');
        return;
      }
      const list = results.map(g => `• ${g.name}`).join('\n');
      bot.sendMessage(chatId, `Ожидают подтверждения:\n${list}`);
    });
  }

  else if (data === 'add_task') {
    userStates[chatId] = 'awaiting_task_description';
    bot.sendMessage(chatId, 'Введите описание задачи:');
  }

  else if (data.startsWith('complete_')) {
    const taskId = parseInt(data.split('_')[1]);
    db.query('UPDATE botdb.tasks SET completed = 1 WHERE id = ?', [taskId], (err) => {
      if (err) {
        bot.sendMessage(chatId, 'Ошибка при отметке.');
        return;
      }
      bot.sendMessage(chatId, 'Задача отмечена как выполненная ✅');
    });
  }

  bot.answerCallbackQuery(query.id);
});

// === MESSAGE HANDLER ===
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  const state = userStates[chatId];
  const userId = msg.from.id;

  if (state === 'awaiting_group_name') {
    const groupName = text.trim();
    db.query('INSERT INTO botdb.adding_groups (name) VALUES (?)', [groupName], (err) => {
      if (err) return bot.sendMessage(chatId, 'Ошибка при заявке на группу.');
      bot.sendMessage(chatId, `Заявка на добавление "${groupName}" отправлена!`);
      delete userStates[chatId];
    });
  }

  else if (state === 'awaiting_task_description') {
    if (!userSessions[chatId]?.groupId) {
      bot.sendMessage(chatId, 'Сначала выберите группу.');
      return;
    }

    userStates[chatId] = { step: 'awaiting_deadline', description: text };
    bot.sendMessage(chatId, 'Введите дедлайн в формате ГГГГ-ММ-ДД:');
  }

  else if (state?.step === 'awaiting_deadline') {
    const deadline = text.trim();
    const { description } = userStates[chatId];
    const groupId = userSessions[chatId]?.groupId;

    db.query(
      'INSERT INTO botdb.tasks (description, deadline, user_id, group_id, subject_id, is_group_task) VALUES (?, ?, ?, ?, ?, ?)',
      [description, deadline, userId, groupId, 1, false], // subject_id = 1 заглушка
      (err) => {
        if (err) {
          console.error(err);
          bot.sendMessage(chatId, 'Ошибка при добавлении задачи.');
        } else {
          bot.sendMessage(chatId, `Задача "${description}" добавлена!`);
        }
        delete userStates[chatId];
      }
    );
  }
});

module.exports = bot;
