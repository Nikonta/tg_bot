const db = require('./connection');

module.exports = (app) => {
  app.get('/createdb', (req, res) => {
    let sql = 'CREATE DATABASE botdb';
    db.query(sql, err => {
      if (err) throw err;
      res.send('База данных создана');
    });
  });

  app.get('/createuserstable', (req, res) => {
  let sql = `
    CREATE TABLE botdb.users (
      id BIGINT PRIMARY KEY,
      chat_id BIGINT NOT NULL,
      username VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
`;
  db.query(sql, err => {
    if (err) throw err;
    res.send('Таблица users создана');
  });
});

  app.get('/creategroupstable', (req, res) => {
    let sql = `
      CREATE TABLE botdb.groups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL
      )
    `;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Таблица groups создана');
    });
  });

  app.get('/addgroups', (req, res) => {
    let sql = `INSERT INTO botdb.groups (name) VALUES ('КБ-21')`;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Группы добавлены');
    });
  });

  app.get('/creatependinggroups', (req, res) => {
    let sql = `
      CREATE TABLE botdb.adding_groups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        status ENUM('ожидает','создана') DEFAULT 'ожидает'
      )
    `;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Таблица pending_groups создана');
    });
  });


  app.get('/createsubjectstable', (req, res) => {
    let sql = `
      CREATE TABLE botdb.subjects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        group_id INT NOT NULL,
        user_id BIGINT NOT NULL,
        status ENUM('ожидает','подтверждено', 'отклонено') DEFAULT 'ожидает',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES botdb.users(id)
      )
    `;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Таблица subjects создана');
    });
  }); 
 

  app.get('/createtaskstable', (req, res) => {
    let sql = `
      CREATE TABLE botdb.tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        description TEXT NOT NULL,
        deadline DATE NOT NULL,
        user_id BIGINT NOT NULL,
        group_id INT NOT NULL,
        subject_id INT NOT NULL,
        is_group_task BOOLEAN DEFAULT FALSE,
        status ENUM('ожидает', 'подтверждено', 'отклонено') DEFAULT 'подтверждено',
        completed BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES botdb.users(id),
        FOREIGN KEY (group_id) REFERENCES botdb.groups(id),
        FOREIGN KEY (subject_id) REFERENCES botdb.subjects(id)
      )
    `;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Таблица tasks создана');
    });
  });
        
  app.get('/createnotificationstable', (req, res) =>{
    let sql =`
    CREATE TABLE botdb.notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT NOT NULL,
    notification_type VARCHAR(50) NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES botdb.tasks(id)
    )
    `;
    db.query(sql, err => {
      if (err) throw err;
      res.send('Таблица notifications создана');
    });
  });   
    
};
