const mysql = require('mysql');
require('dotenv').config();

const db = mysql.createConnection({
  host: 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: 'botdb'
});

db.connect(err => {
  if (err) {
    console.error('Ошибка подключения к MySQL:', err);
    process.exit(1);
  }
  console.log('MySQL подключен');
});

module.exports = db;
