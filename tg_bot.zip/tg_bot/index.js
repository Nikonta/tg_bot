require('dotenv').config();
const express = require('express');
const app = express();
const setupQueries = require('./db/query');
const bot = require('./bot'); 

setupQueries(app);

app.listen(3000, () => {
  console.log('Express сервер запущен на порте 3000');
});